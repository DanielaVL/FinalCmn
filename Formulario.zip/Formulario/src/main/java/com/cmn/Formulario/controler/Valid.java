package com.cmn.Formulario.controler;

public @interface Valid {

}
